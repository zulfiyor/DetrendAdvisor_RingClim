Data downloaded with DeClim / RingClim online tools
Batch started: 2026-10-28T07:10:27

Please cite the data sets:

- Abatzoglou, J.T., Dobrowski, S.Z., Parks, S.A. & Hegewisch, K.C. (2018) TerraClimate, a high-resolution global dataset of monthly climate and climatic water balance from 1958-2015. Scientific Data 5, 170191.
- Harris, I., Osborn, T.J., Jones, P. & Lister, D. (2020) Version 4 of the CRU TS monthly high-resolution gridded multivariate climate dataset. Scientific Data 7, 109. https://doi.org/10.1038/s41597-020-0453-3
- Hersbach, H. et al. (2020) The ERA5 global reanalysis. Q. J. R. Meteorol. Soc. 146, 1999-2049. Data served by Open-Meteo.com (CC BY 4.0), Zippenfenig, P. (2023) Open-Meteo.com Weather API. doi:10.5281/zenodo.7970649
- Karger, D.N. et al. (2017) Climatologies at high resolution for the earth's land surface areas. Scientific Data 4, 170122. Data: Karger et al. (2021) EnviDat, doi:10.16904/envidat.228.v2.1
- Menne, M.J. et al. (2012) An overview of the Global Historical Climatology Network-Daily database. J. Atmos. Oceanic Technol. 29, 897-910. doi:10.7289/V5D21VHZ
- Rohde, R.A. & Hausfather, Z. (2020) The Berkeley Earth Land/Ocean Temperature Record. Earth Syst. Sci. Data 12, 3469-3479.
- Schneider, U. et al. GPCC Full Data Monthly Product, Global Precipitation Climatology Centre, Deutscher Wetterdienst. doi:10.5676/DWD_GPCC
- Vicente-Serrano, S.M., Begueria, S. & Lopez-Moreno, J.I. (2010) A multiscalar drought index sensitive to global warming: the SPEI. J. Climate 23, 1696-1718. McKee, T.B. et al. (1993) SPI.

Not downloaded / problems:
- CHIRPS v3 monthly precipitation (0.05 deg): The CHIRPS server (Climate Hazards Center, UCSB) refused access (HTTP 403). It temporarily blocks computers that send many requests in a short time; try again in a few hours. Months already read are kept in the cache and are not requested again. (HTTP 403 for https://data.chc.ucsb.edu/products/CHIRPS/v3.0/monthly/global/tifs/)
